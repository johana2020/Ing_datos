def contracts_by_month():
	return """SELECT nombre, extract(month FROM fecha_firma) AS mes, COUNT(*) AS cantidad
	FROM contrato JOIN entidadpublica ON(nit_entidadpublica = nit )
	GROUP BY nombre, extract(month FROM fecha_firma)
	ORDER BY 1,2;"""
    
def money_per_entity_by_month():
	return """SELECT ent.nombre, EXTRACT(MONTH FROM co.fecha_firma) AS mes, SUM(co.valor_pagado) AS total_valor
            FROM contrato co JOIN entidadpublica ent ON ent.nit=co.nit_entidadpublica
            WHERE valor_pagado != 0
            GROUP BY ent.nombre, EXTRACT(MONTH FROM co.fecha_firma) ORDER BY SUM(co.valor_pagado)"""

def juridicaXnatural():
	return """SELECT tipo_proveedor,COUNT(*) AS num
            FROM tipoproveedor JOIN proveedor ON(cod_tipo = cod_tipo_tipoproveedor)
            GROUP BY tipo_proveedor"""
            
def areas_mayor_recaudacion():
    return """ select a.area, count(*) cantidad_dinero
                from contrato c join areacontrato a on c.codigo_area_areacontrato = a.codigo_area
                group by a.codigo_area
                order by cantidad_dinero desc """