from Connection import Connection
import datesSQL as sql
import dash, dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
import pandas as pd

external_stylesheets = ["https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css"]

app = dash.Dash(__name__,external_stylesheets = external_stylesheets)


con = Connection()
con.openConnection()
query_contracts_by_month = pd.read_sql_query(sql.contracts_by_month(),con.connection) #grafica juan esteban
query_money_per_entity_by_month = pd.read_sql_query(sql.money_per_entity_by_month(),con.connection)  #grafica laura
query_juridicaXnatural = pd.read_sql_query(sql.juridicaXnatural(),con.connection)  #grafica johana
query_areas_mayor_recaudacion = pd.read_sql_query(sql.areas_mayor_recaudacion(),con.connection)  #grafica johana
con.closeConnection()

contracts_by_month = pd.DataFrame(query_contracts_by_month,columns=["nombre","mes","cantidad"]) #grafica juan esteban
money_per_entity_by_month_df = pd.DataFrame(query_money_per_entity_by_month,columns=["nombre","mes","total_valor"]) #grafica laura
juridicaXnatural_df = pd.DataFrame(query_juridicaXnatural,columns=["tipo_proveedor","num"]) #grafica johana
diego_df = pd.DataFrame(query_areas_mayor_recaudacion, columns = ["area", "cantidad_dinero"])


#GRAFICAS JUAN ESTEBAN
grafica_contratos2 = px.bar(contracts_by_month.head(20),x= ["nombre","mes"], y = "cantidad", color="nombre",labels={"nombre": "Nombre entidad","value":"mes"})
grafica_contratos = px.box(contracts_by_month, x="nombre", y=["mes","cantidad"],labels={"nombre": "Nombre entidad","value":"mes x cantidad"})
grafica_contratos3 = px.scatter(contracts_by_month, x="mes", y="cantidad",
	       size="cantidad", color="cantidad", log_x=True, size_max=60)
#GRAFICAS LAURA
grafica_plata_gastada = px.line(money_per_entity_by_month_df, x="mes", y="total_valor", color='nombre', markers=True)
grafica_plata_gastada2 = px.funnel(money_per_entity_by_month_df, x='total_valor', y='mes', color='nombre')
grafica_plata_gastada3 = px.scatter(money_per_entity_by_month_df, x="mes", y="total_valor", color="nombre",hover_name="nombre", log_x=True, size_max=60)
grafica_plata_gastada4 = px.bar(money_per_entity_by_month_df, x="mes", y="total_valor", color="nombre", title="Diagrama de Barras supersupestas")
#GRAFICA JOHANA

grafica_naturalXjuridica = px.bar(juridicaXnatural_df,x= "tipo_proveedor", y = "num")
#GRAFICAS DIEGO
figPieDiego = px.pie(diego_df.head(20),names = "area", values = "cantidad_dinero")
figBarDiego = px.bar(diego_df.head(20),x = "area", y = "cantidad_dinero", title = "Grafica de Barras")

app.layout = html.Div(children = [html.H1(children = "Ingenieria De Datos Entrega Final", className='text-center'),
                                  dcc.Graph(id = 'grafica_contratos_xmes_cajas',
                                            figure = grafica_contratos),#grafica juan
                                  dcc.Graph(id = 'grafica_contratos_xmes_barras',
                                            figure = grafica_contratos2),#grafica_juan
                                  dcc.Graph(id = 'grafica_contratos_xmes_burbujas',
                                            figure = grafica_contratos3),#grafica_juan
                                  dcc.Graph(id = 'dinero_gastado_por_mes_por_entidad_lineas',
                                            figure = grafica_plata_gastada), #grafica laura
                                  dcc.Graph(id = 'dinero_gastado_por_mes_por_entidad_funnel',
                                            figure = grafica_plata_gastada2), #grafica laura
                                  dcc.Graph(id = 'dinero_gastado_por_mes_por_entidad_scatter',
                                            figure = grafica_plata_gastada3), #grafica laura
                                  dcc.Graph(id = 'dinero_gastado_por_mes_por_entidad_scatter',
                                            figure = grafica_plata_gastada4), #grafica laura
                                  dcc.Graph(id = 'nnnn3',
                                            figure = grafica_naturalXjuridica), #grafica johana
                                  dcc.Graph(id = 'nnnn2',
                                            figure = figPieDiego), #grafica diego
                                  dcc.Graph(id = 'nnnn',
                                            figure = figBarDiego), #grafica diego
                                  ])

if __name__ == '__main__':
    app.run_server(debug = True)
 